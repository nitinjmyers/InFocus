clear all;
clc;
Ptx=-30; % in dB

Ptx_lin=10.^(Ptx/10);
load('heq_wb_freq.mat')
hp=6.625e-34;
kb=1.38e-23;
Tk=290;
Delta_f=freqvec(2)-freqvec(1);

phin_nr=hp*freqvec;
phin_dr=exp(hp*freqvec/(kb*Tk))-1;

phin=phin_nr./phin_dr;  % in watts


Hwb_sq=ModBFvec_off;
N_eff=phin./Hwb_sq;
mu_df=wfill(N_eff,Ptx_lin/Delta_f);
powalloc=mu_df-N_eff;
powalloc(powalloc<0)=0;
SNR_eff=powalloc./N_eff;
Rate_new=Delta_f*sum(log2(1+SNR_eff))

Hwb_sq=BFvec;
N_eff=phin./Hwb_sq;
mu_df=wfill(N_eff,Ptx_lin/Delta_f);
powalloc=mu_df-N_eff;
powalloc(powalloc<0)=0;
SNR_eff=powalloc./N_eff;
Rate_old=Delta_f*sum(log2(1+SNR_eff))
Rate_new/Rate_old

