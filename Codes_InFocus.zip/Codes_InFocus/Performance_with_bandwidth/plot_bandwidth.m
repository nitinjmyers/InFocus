clear all;
clc;

Rates_result=dlmread('angles_Rateold_Ratenew_dist15_BW10.txt');
angles_all=Rates_result(1,:);

BW_vec=[5,10:10:80];
Anglevec=[0,30,60];
Numangles=length(Anglevec);
Ratenew=zeros(Numangles,length(BW_vec));Rateold=Ratenew;
for aa=1:1:Numangles
aindx=find(angles_all==Anglevec(aa));
if(length(aindx)>1)
    aindx=aindx(1);
end    
for bb=1:1:length(BW_vec)
    Rates_result=dlmread(strcat('angles_Rateold_Ratenew_dist15_BW',num2str(BW_vec(bb)),'.txt'));
    Rateold(aa,bb)=Rates_result(2,aindx)/(1e12);
    Ratenew(aa,bb)=Rates_result(3,aindx)/(1e12);
end
end
figure(1)
hold on;
plot(BW_vec,Rateold(1,:),'ro:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(BW_vec,Ratenew(1,:),'bo-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(BW_vec,Rateold(2,:),'rs:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(BW_vec,Ratenew(2,:),'bs-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(BW_vec,Rateold(3,:),'rd:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(BW_vec,Ratenew(3,:),'bd-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
xlim([5,80])
set(gca, 'XTick', BW_vec)
xlab=xlabel('Bandwidth (GHz) ','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Achievable Rate (Tbps)','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
h_legend=legend('Standard design, $$\gamma=0^{\circ}$$','InFocus, $$\gamma=0^{\circ}$$','Standard design, $$\gamma=30^{\circ}$$','InFocus, $$\gamma=30^{\circ}$$','Standard design, $$\gamma=60^{\circ}$$','InFocus, $$\gamma=60^{\circ}$$');
set(h_legend,'Position',[0.161440985543388 0.645714289801461 0.347487585885184 0.255476186389015],'Interpreter','Latex','FontSize',14);

grid on;