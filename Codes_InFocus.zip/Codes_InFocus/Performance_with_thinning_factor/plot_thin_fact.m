clear all;
clc;

Rates_result=dlmread('angles_Rateold_Ratenew_dist15_BW_40_active_rad_mm_10.txt');
angles_all=Rates_result(1,:);
Rthin=dlmread('radius_thinfact.txt');
Radius=Rthin(:,1);
on_frac=Rthin(:,2);
Anglevec=[0,30,60];
Numangles=length(Anglevec);
Ratenew=zeros(Numangles,length(on_frac));Rateold=Ratenew;
for aa=1:1:Numangles
aindx=find(angles_all==Anglevec(aa));
if(length(aindx)>1)
    aindx=aindx(1);
end    
for bb=1:1:length(on_frac)
    Rates_result=dlmread(strcat('angles_Rateold_Ratenew_dist15_BW_40_active_rad_mm_',num2str(round(Radius(bb)*1e3)),'.txt'));
    Rateold(aa,bb)=Rates_result(2,aindx)/(1e12);
    Ratenew(aa,bb)=Rates_result(3,aindx)/(1e12);
end
end
figure(1)
hold on;
subsmp=[1,9,15,19];
plot(on_frac,Rateold(1,:),'ro:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(on_frac(subsmp),Ratenew(1,subsmp),'bo-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(on_frac,Rateold(2,:),'rs:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(on_frac(subsmp),Ratenew(2,subsmp),'bs-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(on_frac,Rateold(3,:),'rd:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(on_frac(subsmp),Ratenew(3,subsmp),'bd-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
a=0.02; % horizontal radius
b=0.32; % vertical radius
x0=0.1; % x0,y0 ellipse centre coordinates
y0=3.45;
t=-pi:0.01:pi;
x=x0+a*cos(t);
y=y0+b*sin(t);
plot(x,y,'k-','LineWidth',2)
x = [0.3 0.21];
y = [0.9 0.87];
str={'$$N_{\mathrm{tx}}$$ active antennas'};
annotation('textarrow',x,y,'interpreter','latex','LineWidth',2,'FontSize',16,'String',str);
xlim([0,1])
set(gca, 'XTick', [0.01,0.2:0.2:1])
xlab=xlabel('Fraction of active antennas $$\delta$$','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Achievable Rate (Tbps)','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
h_legend=legend('Thinned array, $$\gamma=0^{\circ}$$','InFocus, $$\gamma=0^{\circ}$$','Thinned array, $$\gamma=30^{\circ}$$','InFocus, $$\gamma=30^{\circ}$$','Thinned array, $$\gamma=60^{\circ}$$','InFocus, $$\gamma=60^{\circ}$$');
set(h_legend,'Position',[0.552512414114817 0.117142861230032 0.347487585885184 0.255476186389015],'Interpreter','Latex','FontSize',14);

grid on;