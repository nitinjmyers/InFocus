clear all;
clc;
fc=300e9;

c=3e8;    % light speed
depth_design=15e-2;
angle_design=0*(pi/180);
drx_x=-depth_design*sin(angle_design);
drx_z=depth_design*cos(angle_design);
%location of the target rx (drx_x,0,drx_z)
BW_des=40e9;
BW_eval=80e9;
Lb=c/fc;
spac=Lb/2;
qbit=2;
plotid=1;


%% TX parameters
L=20e-2;  % in m Array of length LxL , center at (0,0)
Radius=L/2;
LIS_f=0; % If 0, usual Los channel model - isotropic antennas, If 1  non-isotropic LIS
N=round(L/spac);
xcoord=linspace(-L/2,L/2,N);
ycoord=xcoord;
[xx,yy]=meshgrid(xcoord,ycoord);
coord_mat=xx+1i*yy;

%% RX parameters
Distmat_2D=abs(coord_mat-drx_x);
Distmat=sqrt(abs(Distmat_2D).^2+drx_z^2);
Dist_arr=abs(coord_mat);
Hmat=(Lb/(2*pi))*exp(-1i*2*pi*fc*Distmat/c)./(Distmat.^(2*LIS_f+1));%
Hmat(Dist_arr>Radius)=0;
Nactiv=sum(Dist_arr(:)<=Radius);
BFmat=exp(-1i*angle(Hmat));
QBFmat=quantz(exp(-1i*angle(Hmat)),qbit)/sqrt(Nactiv);


%% InFocus
if(abs(drx_x)<Radius)
    d1=drx_z; d2=sqrt((Radius-abs(drx_x))^2+drx_z^2); d3=sqrt((Radius+abs(drx_x))^2+drx_z^2);
    %numerical integration to get phase
    Ngrid=1000;
    distgrid=linspace(d1,d3,Ngrid);
    rgrid=sqrt(distgrid.^2-drx_z^2);
    modfn=zeros(size(distgrid));modfnNR=modfn;
    modfn(distgrid<=d2)=2*pi;
    indx_rem=find(distgrid>d2);
    modfnNR(indx_rem)=rgrid(indx_rem).^2+(abs(drx_x)^2)-(Radius^2);
    modfn(indx_rem)=real(2*acos(modfnNR(indx_rem)./(2*rgrid(indx_rem)*abs(drx_x))));
    modfn=modfn.^2;
else
    d1=sqrt((abs(drx_x)-Radius)^2+drx_z^2); d2=sqrt((abs(drx_x)+Radius)^2+drx_z^2);
    %numerical integration to get phase
    Ngrid=1000;
    distgrid=linspace(d1,d2,Ngrid);
    rgrid=sqrt(distgrid.^2-drx_z^2);
    modfnNR=rgrid.^2+(abs(drx_x)^2)-(Radius^2);
    modfnarg=modfnNR./(2*rgrid*abs(drx_x));
    modfn=(2*acos(modfnarg)).^2;
end
modfn=modfn./(distgrid.^(LIS_f*2));%ones(size(modfn./(distgrid.^(LIS_f*2))));
freq_temp=cumsum(modfn)/Ngrid;
scal=(2*pi*BW_des/c)/(freq_temp(end)-freq_temp(1));
freq_temp=freq_temp*scal;
freq_temp=freq_temp+(-pi*BW_des/c)-freq_temp(1);
phase_mod=cumsum(freq_temp)*(distgrid(2)-distgrid(1)); % as a function of rgrid- integration factor - (2*Radius)/Ngrid
indx_valid=(Dist_arr<=Radius);
GMod_off=exp(1i*compute_phase(Distmat,phase_mod,distgrid,indx_valid));
ModBFmat=quantz(GMod_off.*BFmat,qbit)/sqrt(Nactiv);
ModBFmat=ModBFmat.*(indx_valid);


% Fig. 1 for BF gain vs frequency
SNRloss=[];
delta=[];
for testrad= [6e-2, 8e-2, 10e-2]
Mask=zeros(size(coord_mat));
indx_on=find(abs(coord_mat)<testrad);
Mask(indx_on)=1;
BFvec=[];
ModBFvec=[];
delta=[delta;sum(Mask(:))/Nactiv];
freqvec=linspace(fc-BW_eval/2,fc+BW_eval/2,121);
% Perturbation
for freq=freqvec
    Htest_mat=(c/(2*pi*freq))*exp(-1i*2*pi*freq*Distmat/c)./(Distmat.^(2*LIS_f+1));
    Htest_mat(Dist_arr>Radius)=0;
    Htest_mat(Mask==0)=0;
    BFvec=[BFvec,abs(sum(sum(Htest_mat.*QBFmat)))^2];
end
BFmax=abs(sum(sum(Hmat.*QBFmat)))^2;
SNRloss=[SNRloss;10*log10(BFvec)];
end

% InFocus-beam
BFvec=[];
for freq=freqvec
    Htest_mat=(c/(2*pi*freq))*exp(-1i*2*pi*freq*Distmat/c)./(Distmat.^(2*LIS_f+1));
    Htest_mat(Dist_arr>Radius)=0;
    Htest_mat(Mask==0)=0;
    BFvec=[BFvec,abs(sum(sum(Htest_mat.*ModBFmat)))^2];
end
SNRloss=[SNRloss;10*log10(BFvec)];
infoc_ind=[1:10:121];
plot(freqvec/(1e9),zeros(size(freqvec)),'bo-','LineWidth',2,'MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','w')
hold on;
plot(freqvec/(1e9),SNRloss(3,:),'r-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(freqvec/(1e9),SNRloss(2,:),'r--','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(freqvec/(1e9),SNRloss(1,:),'r:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(freqvec/(1e9),SNRloss(4,:),'b-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(freqvec(infoc_ind)/(1e9),SNRloss(4,infoc_ind),'bo','LineWidth',2,'MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','w')

h_legend=legend('InFocus, $$\delta=1$$','Standard design, $$\delta=1$$','Standard design, $$\delta=0.64$$','Standard design, $$\delta=0.36$$');
set(h_legend, 'Position',[0.33078967503139 0.135238097962879 0.354924610682896 0.173095235370454],'Interpreter','Latex','FontSize',14);
xlab=xlabel('Frequency (GHz)','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Equivalent channel response (dB)','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
ylim([-71,-5])
yticks([-70:10:-10,-5])
grid on;
