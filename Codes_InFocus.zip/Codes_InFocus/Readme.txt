1) Run 2D_surf_plot_Infocus/compute_energy_spread.m for surface plot
2) Run Performance_with_angle_and_distance/compute_rate.m to get achievable rate with InFocus and standard beamforming. This code generates several .txt files containing the achievable rate information.
3) Then, run Performance_with_angle_and_distance/plot_angle.m and Performance_with_angle_and_distance/plot_dist.m to get the rate vs angle and distance plots.

Follow the procedure similar to 2-3 to get rate with other parameters.
