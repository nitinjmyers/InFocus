clear all;
clc;

Rates_result=dlmread('angles_Rateold_Ratenew_dist15.txt');
angles_all=Rates_result(1,:);

Distvec=[10:5:80];
indx=[1:2:length(Distvec)];
Anglevec=[0,30,60];
Numangles=length(Anglevec);
Ratenew=zeros(Numangles,length(Distvec));Rateold=Ratenew;
for aa=1:1:Numangles
aindx=find(angles_all==Anglevec(aa));
if(length(aindx)>1)
    aindx=aindx(1);
end    
for dd=1:1:length(Distvec)
    Rates_result=dlmread(strcat('angles_Rateold_Ratenew_dist',num2str(Distvec(dd)),'.txt'));
    Rateold(aa,dd)=Rates_result(2,aindx)/(1e12);
    Ratenew(aa,dd)=Rates_result(3,aindx)/(1e12);
end
end
figure(1)
hold on;
plot([10,80],[5,5],'ro:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot([10,80],[5,5],'bo-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot([10,80],[5,5],'rs:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot([10,80],[5,5],'bs-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot([10,80],[5,5],'rd:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot([10,80],[5,5],'bd-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')

plot(Distvec,Rateold(1,:),'r:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Distvec,Ratenew(1,:),'b-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(Distvec,Rateold(2,:),'r:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Distvec,Ratenew(2,:),'b-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(Distvec,Rateold(3,:),'r:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Distvec,Ratenew(3,:),'b-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(Distvec(indx),Rateold(1,indx),'ro','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Distvec(indx),Ratenew(1,indx),'bo','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(Distvec(indx),Rateold(2,indx),'rs','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Distvec(indx),Ratenew(2,indx),'bs','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(Distvec(indx),Rateold(3,indx),'rd','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Distvec(indx),Ratenew(3,indx),'bd','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')

set(gca, 'XTick', Distvec(indx))
xlab=xlabel('Distance from the TX center $$\ell$$ (cm)','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Achievable Rate (Tbps)','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
ylim([0,4])
h_legend=legend('Standard design, $$\gamma=0^{\circ}$$','InFocus, $$\gamma=0^{\circ}$$','Standard design, $$\gamma=30^{\circ}$$','InFocus, $$\gamma=30^{\circ}$$','Standard design, $$\gamma=60^{\circ}$$','InFocus, $$\gamma=60^{\circ}$$');
set(h_legend,'Position',[0.141798128400531 0.12428571837289 0.347487585885184 0.255476186389015],'Interpreter','Latex','FontSize',14);

grid on;