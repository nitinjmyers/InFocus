clear all;
clc
qbit=2;
fc=300e9;
c=3e8;
depth_vec=[10:5:80]; % in cm

for dd = 1:1:length(depth_vec)
    depth_design=depth_vec(dd)*1e-2; % Also use 45 to get Rate vs angle curve in InFocus paper
    BW_des=40e9;
    Ptx=0; % in dBm
    Ptx_lin=10.^((Ptx-30)/10); % in watts
    angle_eval=[0:5:75];
    Lb=c/fc;
    spac=Lb/2;
    hp=6.625e-34;
    kb=1.38e-23;
    Tk=290;
    %% TX parameters
    L=20e-2;  % in m Array of length LxL , center at (0,0)
    Radius=L/2;
    LIS_f=0; % If 0, usual Los channel model - isotropic antennas, If 1  non-isotropic LIS
    N=round(L/spac);
    xcoord=linspace(-L/2,L/2,N);
    ycoord=xcoord;
    [xx,yy]=meshgrid(xcoord,ycoord);
    coord_mat=xx+1i*yy;
    Nsub=256;   % no. of subcarriers for rate computation
    
    Rates=zeros(2,length(angle_eval));
    tic
    for aa=1:1:length(angle_eval)
        
        angle_degrees=angle_eval(aa);
        angle_design=pi*angle_degrees/180;
        drx_x=-depth_design*sin(angle_design);
        drx_z=depth_design*cos(angle_design);
        %location of the target rx (drx_x,0,drx_z)
        %% RX parameters
        Distmat_2D=abs(coord_mat-drx_x);
        Distmat=sqrt(abs(Distmat_2D).^2+drx_z^2);
        Dist_arr=abs(coord_mat);
        Hmat=(Lb/(2*pi))*exp(-1i*2*pi*fc*Distmat/c)./(Distmat.^(2*LIS_f+1));%
        Hmat(Dist_arr>Radius)=0;
        Nactiv=sum(Dist_arr(:)<=Radius);
        BFmat=exp(-1i*angle(Hmat));
        QBFmat=quantz(exp(-1i*angle(Hmat)),qbit)/sqrt(Nactiv);
        
        if(abs(drx_x)<Radius)
            d1=drx_z; d2=sqrt((Radius-abs(drx_x))^2+drx_z^2); d3=sqrt((Radius+abs(drx_x))^2+drx_z^2);
            %numerical integration to get phase
            Ngrid=1000;
            distgrid=linspace(d1,d3,Ngrid);
            rgrid=sqrt(distgrid.^2-drx_z^2);
            modfn=zeros(size(distgrid));modfnNR=modfn;
            modfn(distgrid<=d2)=2*pi;
            indx_rem=find(distgrid>d2);
            modfnNR(indx_rem)=rgrid(indx_rem).^2+(abs(drx_x)^2)-(Radius^2);
            modfn(indx_rem)=real(2*acos(modfnNR(indx_rem)./(2*rgrid(indx_rem)*abs(drx_x))));
            modfn=modfn.^2;
        else
            d1=sqrt((abs(drx_x)-Radius)^2+drx_z^2); d2=sqrt((abs(drx_x)+Radius)^2+drx_z^2);
            %numerical integration to get phase
            Ngrid=1000;
            distgrid=linspace(d1,d2,Ngrid);
            rgrid=sqrt(distgrid.^2-drx_z^2);
            modfnNR=rgrid.^2+(abs(drx_x)^2)-(Radius^2);
            modfnarg=modfnNR./(2*rgrid*abs(drx_x));
            modfn=(2*acos(modfnarg)).^2;
        end
        modfn=modfn./(distgrid.^(LIS_f*2));%ones(size(modfn./(distgrid.^(LIS_f*2))));
        freq_temp=cumsum(modfn)/Ngrid;
        scal=(2*pi*BW_des/c)/(freq_temp(end)-freq_temp(1));
        freq_temp=freq_temp*scal;
        freq_temp=freq_temp+(-pi*BW_des/c)-freq_temp(1);
        phase_mod=cumsum(freq_temp)*(distgrid(2)-distgrid(1)); % as a function of rgrid- integration factor - (2*Radius)/Ngrid
        indx_valid=(Dist_arr<=Radius);
        GMod_off=exp(1i*compute_phase(Distmat,phase_mod,distgrid,indx_valid));
        ModBFmat=quantz(GMod_off.*BFmat,qbit)/sqrt(Nactiv);
        ModBFmat=ModBFmat.*(indx_valid);
        QBFmat=QBFmat.*(indx_valid);
        %% Compute equivalent SISO channels here
        freqvec=2*pi*linspace(fc-BW_des/2,fc+BW_des/2,Nsub);
        antt_delays=Distmat(:)/c;
        AF_product=antt_delays*freqvec;
        
        Wb_mch=exp(-1i*AF_product)./AF_product;
        SCpowers_new=abs(ModBFmat(:).'*Wb_mch).^2;
        SCpowers_old=abs(QBFmat(:).'*Wb_mch).^2;
        %% Compute rate
        
        Delta_f=freqvec(2)-freqvec(1);
        
        phin_nr=hp*freqvec;
        phin_dr=exp(hp*freqvec/(kb*Tk))-1;
        
        phin=phin_nr./phin_dr;  % in watts
        
        Hwb_sq=SCpowers_old;
        N_eff=phin./Hwb_sq;
        mu_df=wfill(N_eff,Ptx_lin/Delta_f);
        powalloc=mu_df-N_eff;
        powalloc(powalloc<0)=0;
        SNR_eff=powalloc./N_eff;
        Rates(1,aa)=Delta_f*sum(log2(1+SNR_eff));
        
        Hwb_sq=SCpowers_new;
        N_eff=phin./Hwb_sq;
        mu_df=wfill(N_eff,Ptx_lin/Delta_f);
        powalloc=mu_df-N_eff;
        powalloc(powalloc<0)=0;
        SNR_eff=powalloc./N_eff;
        Rates(2,aa)=Delta_f*sum(log2(1+SNR_eff));
    end
    angles_all=[-angle_eval(end:-1:2),angle_eval];
    indx_all=[length(angle_eval):-1:2,1:1:length(angle_eval)];
    Rates_result=[angles_all;Rates(:,indx_all)];
    toc
    dlmwrite(strcat('angles_Rateold_Ratenew_dist',num2str(round(depth_design*100)),'.txt'),Rates_result);
end