clear all;
clc;

Rates_result=dlmread('angles_Rateold_Ratenew_dist15.txt');
Anglevec=Rates_result(1,:);
indx=[1:3:length(Anglevec)];
Distvec=[15,45,75];
Numdist=length(Distvec);
Ratenew=zeros(Numdist,length(Anglevec));Rateold=Ratenew;
for nn=1:1:Numdist
    dist=Distvec(nn);
    Rates_result=dlmread(strcat('angles_Rateold_Ratenew_dist',num2str(dist),'.txt'));
    Rateold(nn,:)=Rates_result(2,:)/(1e12);
    Ratenew(nn,:)=Rates_result(3,:)/(1e12);
end
figure(1)
hold on;
plot([-75,75],[5,5],'ro:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot([-75,75],[5,5],'bo-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot([-75,75],[5,5],'rs:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot([-75,75],[5,5],'bs-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')

plot(Anglevec,Rateold(1,:),'r:','LineWidth',2)
plot(Anglevec,Ratenew(1,:),'b-','LineWidth',2)
plot(Anglevec,Rateold(2,:),'r:','LineWidth',2)
plot(Anglevec,Ratenew(2,:),'b-','LineWidth',2)
plot(Anglevec(indx),Rateold(1,indx),'ro','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Anglevec(indx),Ratenew(1,indx),'bo','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(Anglevec(indx),Rateold(2,indx),'rs','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(Anglevec(indx),Ratenew(2,indx),'bs','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')

ylim([0.5,4])
xlim([-75,75])
set(gca, 'XTick', Anglevec(indx))
xlab=xlabel('Angle with the boresight $$\gamma$$ (degrees)','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Achievable Rate (Tbps)','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
h_legend=legend('Standard design, $$\ell=15\,\mathrm{cm}$$','InFocus, $$\ell=15\,\mathrm{cm}$$','Standard design, $$\ell=45\,\mathrm{cm}$$','InFocus, $$\ell=45\,\mathrm{cm}$$');
set(h_legend,'Position',[0.322906521388463 0.125714288439069 0.36995062146868 0.173095235370454],'Interpreter','Latex','FontSize',14);

grid on;