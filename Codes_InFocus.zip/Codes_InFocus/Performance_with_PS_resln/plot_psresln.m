clear all;
clc;

Rates_result=dlmread('angles_Rateold_Ratenew_dist15qbit1.txt');
angles_all=Rates_result(1,:);

PSresln=[1:1:5];
Anglevec=[0,30,60];
Numangles=length(Anglevec);
Ratenew=zeros(Numangles,length(PSresln));Rateold=Ratenew;
for aa=1:1:Numangles
aindx=find(angles_all==Anglevec(aa));
if(length(aindx)>1)
    aindx=aindx(1);
end    
for qq=1:1:length(PSresln)
    Rates_result=dlmread(strcat('angles_Rateold_Ratenew_dist15qbit',num2str(PSresln(qq)),'.txt'));
    Rateold(aa,qq)=Rates_result(2,aindx)/(1e12);
    Ratenew(aa,qq)=Rates_result(3,aindx)/(1e12);
end
end
figure(1)
hold on;
plot(PSresln,Rateold(1,:),'ro:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(PSresln,Ratenew(1,:),'bo-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(PSresln,Rateold(2,:),'rs:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(PSresln,Ratenew(2,:),'bs-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
plot(PSresln,Rateold(3,:),'rd:','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
plot(PSresln,Ratenew(3,:),'bd-','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','w')
xlim([1,5])
set(gca, 'XTick', PSresln)
xlab=xlabel('Resolution of phase shifters ','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Achievable Rate (Tbps)','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
h_legend=legend('Standard design, $$\gamma=0^{\circ}$$','InFocus, $$\gamma=0^{\circ}$$','Standard design, $$\gamma=30^{\circ}$$','InFocus, $$\gamma=30^{\circ}$$','Standard design, $$\gamma=60^{\circ}$$','InFocus, $$\gamma=60^{\circ}$$');
set(h_legend,'Position',[0.161440985543388 0.645714289801461 0.347487585885184 0.255476186389015],'Interpreter','Latex','FontSize',14);

grid on;